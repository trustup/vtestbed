/* Linear Systems */
#include "controldc_model.h"
#include "controldc_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* linear systems */


#if defined(__cplusplus)
}
#endif

